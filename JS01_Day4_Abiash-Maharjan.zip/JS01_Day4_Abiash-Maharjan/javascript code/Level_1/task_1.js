//Task 1
/*declare variables, but assign values to those variables after declaration on the next line
and show it on a popup and in a console*/
var vrbl;
vrbl=100;
console.log(vrbl);
alert("You enter varaible " + vrbl);