//Task-2
/*use a different naming convention and create a few variables of your choice and store values 
of different data types in it.*/

//Camel casing and number datatype
var usingNumberVariable;
usingNumberVariable = 100;
console.log(usingNumberVariable);

//Snake casing and string datatype
var using_snake_variable;
using_snake_variable = 'Abilash Maharjan';
console.log(using_snake_variable);

//big int datatype
let usingBigIntDatatype;
usingBigIntDatatype = 54645354213434;
console.log(usingBigIntDatatype);

const sym1 = Symbol("a1");
console.log("Symbol is",sym1);

//null datatype
let nullDataType = null;
console.log(nullDataType);
console.log(typeof(nullDataType));

//undefined datatype
let undefineDataType = undefined;
console.log(undefineDataType);
console.log(typeof(undefineDataType));