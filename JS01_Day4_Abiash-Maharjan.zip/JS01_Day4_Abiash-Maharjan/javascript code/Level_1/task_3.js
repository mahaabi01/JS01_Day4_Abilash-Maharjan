//Task 3
/*Take 2 different inputs using prompt() and use string concatenation operator 
to show the results in the console*/

let firstName = prompt("Enter your first name:");
let lastName  = prompt("Enter your last name:");
alert("Your full name is " + firstName + " " + lastName+".");