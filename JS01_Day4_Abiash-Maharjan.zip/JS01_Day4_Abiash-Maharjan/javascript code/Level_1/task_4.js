//Task 4
//Show warning error in the console
console.warn("Your device is over heated.");