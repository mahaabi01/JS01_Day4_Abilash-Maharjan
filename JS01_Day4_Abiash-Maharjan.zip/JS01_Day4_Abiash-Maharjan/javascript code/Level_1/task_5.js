//Task 5
// Explore what is dynamically typed language, and why is js a dynamically typed language

