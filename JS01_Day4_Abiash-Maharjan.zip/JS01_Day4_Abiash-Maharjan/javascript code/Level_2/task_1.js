//Task 1
/*Perform addition, subtraction, multiplication, and division by taking input using 
the prompt() function and show all the results by concatenating it with a string 
like: sum is ... , product is ...*/

//taking input
let num1 = prompt("Enter first number:");
let num2 = prompt("Enter second number:");
console.log("Sum is "+' '+ (parseInt(num1) + parseInt(num2)));
console.log("Difference is "+' '+ (parseInt(num1) - parseInt(num2)));
console.log("Product is "+' '+ (parseInt(num1) * parseInt(num2)));
console.log("Division is "+' '+ (parseInt(num1) / parseInt(num2)));