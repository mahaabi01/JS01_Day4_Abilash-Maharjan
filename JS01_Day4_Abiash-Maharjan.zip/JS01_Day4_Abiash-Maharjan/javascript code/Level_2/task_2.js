//Task 2
/*Declare 5 different variables using let and 5 different variables 
using var but don't assign values to it and log all those variables in the console*/

let var1;
let var2;
let var3;
let var4;
let var5;

console.log(var1,var2,var3,var4,var5);

var var6;
var var7;
var var8;
var var9;
var var10;

console.log(var6,var7,var8,var9,var10);