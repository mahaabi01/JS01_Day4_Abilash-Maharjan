//Task 3
/*Create a constant and try to create another constant with the same name and see what happens, 
fix the mistake if something goes wrong.*/

const vrbl=10;
//const vrbl=20;
//'vrbl' was not able to declare again because it is constant one so error message was shown. 
// If we want to declare the same name for both case we may use var in other to get access to
// use same name multiple times in the same program
console.log(vrbl);

var vrbl1 = 100;
var vrbl1 = 200;
console.log(vrbl1);

//in case of var the latest updated value is shown in console.
