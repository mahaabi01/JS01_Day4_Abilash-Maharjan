//Task 4
/*Declare two variables using let on the same line without terminating the line
 and store true value in both the variables and perform addition and show the result
  on the console and try to analyze the code.*/

  let vrbl1, vrbl2;
  vrbl1 = true;
  vrbl2 = true;
  console.log(vrbl1+vrbl2);
  //true refers to 1 in programming so when we add vrbl1 and vrbl2 we get 2 as 1+1=2