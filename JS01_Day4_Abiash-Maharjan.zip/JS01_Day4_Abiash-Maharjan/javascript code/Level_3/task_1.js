//Task 1
//Explore parseFloat() function and pass integer like 1 or 2 and show the result of it on the console

var vrbl1 = 1;
var vrbl2 = 2;
console.log(parseFloat(vrbl1)+parseFloat(vrbl2));