//Task 2
//Use the + unary operator in a string that contains the number '999' and add 1 to it and 
//show the output on the console. Note: the output should be 1000

var num = '999';
num++;
console.log(num);