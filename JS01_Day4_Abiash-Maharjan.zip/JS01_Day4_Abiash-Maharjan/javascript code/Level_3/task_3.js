// Task 3
// Use the - unary operator to the string containing a number and show the message into the console

let number1 = '100';
number1--;
console.log(number1);