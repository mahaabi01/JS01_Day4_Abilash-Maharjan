//Task 4    
//Identify the data type of the value returned by typeof operator (Hint: you can test it on the console)
let abyhow = 'Avilash';
console.log(typeof(abyhow));

//shown that the datatype is string in the console screen