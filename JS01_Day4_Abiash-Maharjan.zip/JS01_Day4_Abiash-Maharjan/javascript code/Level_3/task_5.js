//Task 5
//Store string using double-quote syntax and try to show something like Ram said, "Programming is a fun game."

let string = "\"Programming is a fun game.\""
console.log("Ram said, "+string);