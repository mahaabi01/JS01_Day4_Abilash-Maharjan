//Task 6
/*Create an object using object literal syntax and use variable name email for creating an object,
create properties like: sendTo and sentFrom properties and give values to it, create send method 
which will log the message like "message sent."*/

//Object
let email = {
    sentTo      : "Abilash",
    sentFrom    : "Aadit",
    send        : function(){
        console.log("Email sent from "+email.sentFrom+" to " + email.sentTo+".");
    }
}
email.send();