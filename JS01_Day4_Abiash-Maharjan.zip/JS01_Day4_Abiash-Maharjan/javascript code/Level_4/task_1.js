//Task 1
//Create a variable to store the name of the city you live in and test it on the console.

var cityName = "Bungamati";
console.log(cityName);
console.log(typeof(cityName));