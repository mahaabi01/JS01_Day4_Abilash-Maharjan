//task 10
//try to declare the constant without assigning the value to it and see the result, 
//also try to re-assign the value to the same constant and see the result.

const value;
const value = 100;
console.log(value);

//Uncaught SyntaxError: Missing initializer in const declaration