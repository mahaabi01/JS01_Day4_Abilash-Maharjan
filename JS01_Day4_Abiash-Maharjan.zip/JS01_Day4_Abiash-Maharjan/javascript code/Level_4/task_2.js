//task 2
//Create a variable named isProgrammingEngaging and supply any boolean value you prefer to supply
let isProgrammingEngaging = true;
console.log(isProgrammingEngaging);
console.log(typeof(isProgrammingEngaging));