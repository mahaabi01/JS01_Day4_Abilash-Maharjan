//task 3
/*Let's suppose I want to store my age, what would be the appropriate data type to store age,
and initialize that variable with the appropriate value. In the end, don't forget to see it 
on the console and finally analyze the result.*/

let myAge = 19;
console.log(myAge);
console.log(typeof(myAge));