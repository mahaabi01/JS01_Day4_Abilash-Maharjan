//task 4
/*I want to store a value that represents nothingness into a variable, 
let's say the variable name is totalUsers, what would be the preferred value to store there?*/

let totalUsers = null;
console.log("The total number of user is "+totalUsers+".");
console.log(typeof(totalUsers));