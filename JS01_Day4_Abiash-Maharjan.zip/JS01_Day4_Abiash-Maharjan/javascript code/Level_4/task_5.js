//task 5
//what might be the solution in case if I wanted to store a phone number 
//into  a variable, which data type would suit this scenario.

let myPhoneNumber = 9863483136;
console.log("My phone number is "+myPhoneNumber+".");
console.log(typeof(myPhoneNumber));