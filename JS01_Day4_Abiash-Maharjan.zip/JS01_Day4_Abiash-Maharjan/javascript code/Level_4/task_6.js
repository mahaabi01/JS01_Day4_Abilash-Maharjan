//task 6
/*Scenario: I wanted to store data related to a specific object. For that create an object which would
 store some information related to the laptop you use.*/

let laptop = {
    brand               : "Acer",
    price               : "90000",
    opertating_system   : "Windows 11",
    RAM                 : "6GB",
    hardDiskInfo        : "500GBsdd",

}
console.log(laptop);

