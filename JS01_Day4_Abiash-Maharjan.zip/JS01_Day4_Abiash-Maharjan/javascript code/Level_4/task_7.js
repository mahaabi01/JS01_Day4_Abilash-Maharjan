//task 4
/*Create an object where the object keys store values of different data types and use typeof operator
 to check the data type of the value that you stored into it.*/

 let obj = {
     number : 1,
     stng   : 'Hello',
     bigint : 1n,
     none   : null
 }
 console.log(obj);
 console.log(typeof(obj.number));
 console.log(typeof(obj.stng));
 console.log(typeof(obj.bigint));
 console.log(typeof(none));