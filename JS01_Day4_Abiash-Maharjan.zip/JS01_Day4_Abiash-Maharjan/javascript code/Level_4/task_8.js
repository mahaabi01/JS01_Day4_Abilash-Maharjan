//task 8
//use typeof operator to check the value returned by the prompt() function
let test = prompt("Enter what you want:");
console.log("The datatype of value return by prompt is "+ typeof(test)+".");
