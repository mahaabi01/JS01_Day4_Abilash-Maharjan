//task 9
//Create a constant that holds a value called red in BG_COLOR constant

const BG_COLOR = 'red';
console.log(BG_COLOR);